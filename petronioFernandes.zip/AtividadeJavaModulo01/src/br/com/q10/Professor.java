package br.com.q10;

public class Professor {
	
	//ATRIBUTOS DE PROFESSOR
	String nome;
	String disciplina;
	int idade;
	int matricula;

}
