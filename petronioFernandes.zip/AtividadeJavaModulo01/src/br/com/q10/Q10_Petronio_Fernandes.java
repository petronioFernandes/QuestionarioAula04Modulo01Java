/*
 * Crie as seguintes classes: Aluno e Professor. 
 * Crie 2 variaveis de referencia para Aluno e 3 para Professor.
 * Instancie 1 variavel do tipo aluno e 2 do tipo Professor.
 * */

package br.com.q10;

public class Q10_Petronio_Fernandes {
	public static void main(String[] args) {
		
		//VARIAVEIS DE REFERENCIA
		Aluno aluno1 = new Aluno();
		Aluno aluno2 = new Aluno();
		Professor professor1 = new Professor();
		Professor professor2 = new Professor();
		Professor professor3 = new Professor();

	}
		
}
