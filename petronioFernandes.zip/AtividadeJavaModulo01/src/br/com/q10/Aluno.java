package br.com.q10;

public class Aluno {
	
	//ATRIBUTOS DE ALUNO
	String nome;
	String disciplina;
	int idade;
	int matricula;
	
}
