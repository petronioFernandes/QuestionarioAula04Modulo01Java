package br.com.q11;

public class Aluno {
	
	String nome;
	double nota;
	int idade;
	
}
