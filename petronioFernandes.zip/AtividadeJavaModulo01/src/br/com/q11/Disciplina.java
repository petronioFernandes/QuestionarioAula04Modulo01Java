	package br.com.q11;

public class Disciplina {
	
	int cargaHoraria;

}
