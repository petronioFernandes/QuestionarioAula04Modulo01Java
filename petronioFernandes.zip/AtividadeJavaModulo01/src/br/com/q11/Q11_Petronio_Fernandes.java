package br.com.q11;

public class Q11_Petronio_Fernandes {
	public static void main(String[] args) {
		
		Aluno aluno1 = new Aluno();
		Aluno aluno2 = new Aluno();
		Disciplina disciplina1 = new Disciplina();
		Disciplina disciplina2 = new Disciplina();
				
	}

}
