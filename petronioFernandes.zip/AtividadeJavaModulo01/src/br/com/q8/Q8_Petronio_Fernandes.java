/*
 * Escreva um algoritimo utilizando java que receba 5 argumentos de entrada. 
 * Caso um dos argumentos seja igual a "-help" voc� ir� exibir o texto: 
 * "Este programa n�o possiu menu de ajuda."
 * */

package br.com.q8;

public class Q8_Petronio_Fernandes {
	public static void main(String[] args) {
		
		for (String argumentos : args) {
			
			System.out.println(argumentos);
		}
	}
}