package br.com.q13;

public class Teclado {
	
	String marca;
	int quantTeclas;
	
	public Teclado(String marca, int quantTeclas) {
		
	}
	

	void digitar() {
		
	}

}
