package br.com.q13;

public class Q13_Petronio_Fernandes {
	public static void main(String[] args) {
		
		Cachorro cachorro = new Cachorro("Vira lata", 4);
		Mouse mouse = new Mouse("Logitech", 3);
		Professor profesor = new Professor("Eric", 54321);
		Teclado teclado = new Teclado("Logitech", 120);
		
	}

}
