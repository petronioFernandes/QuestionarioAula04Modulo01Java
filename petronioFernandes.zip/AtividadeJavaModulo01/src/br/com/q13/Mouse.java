package br.com.q13;

public class Mouse {
	
	String marca;
	int quantTeclas;
	
	public Mouse(String marca, int quantTeclas) {
		
	}
	
	void usarScroll() {
		
	}

}
