package br.com.q13;

public class Cachorro {
	
	String raca;
	int idade;
	
	//construtor com os parametros da classe
	public Cachorro(String raca, int idade) {
		
	}
	
	//comportamento/metodo
	void latir() {
		
	}

}
