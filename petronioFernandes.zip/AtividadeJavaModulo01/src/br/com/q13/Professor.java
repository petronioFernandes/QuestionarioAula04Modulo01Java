package br.com.q13;

public class Professor {
	
	String nome;
	int matricula;
	
	public Professor(String nome, int matricula) {
		
	}
	
	void ensinar() {
		
	}

}
