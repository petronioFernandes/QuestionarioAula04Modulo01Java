package br.com.q12;

public class Q12_Petronio_Fernandes {
	public static void main(String[] args) {
		
		Carro carro1 = new Carro();
	}

}
