package br.com.q12;

public class Carro {
	
	String nome;
	String marca;
	int ano;
	
	void acelerar() {
		
	}
	
	void frear () {
		
	}

}
